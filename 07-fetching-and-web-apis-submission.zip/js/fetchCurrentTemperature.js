import fetch from "../include/fetch.js";
export function fetchCurrentTemperature(coords) {
    // TODO
    const url = `https://220.maxkuechen.com/currentTemperature/forecast?latitude=${coords.lat}&longitude=${coords.lon}&hourly=temperature_2m&temperature_unit=fahrenheit`;
    return fetch(url)
        .then(response => response.json())
        .then((res) => ({
        time: res.hourly.time,
        temperature_2m: res.hourly.temperature_2m,
    }));
}
//# sourceMappingURL=fetchCurrentTemperature.js.map