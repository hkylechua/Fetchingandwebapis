import fetch from "../include/fetch.js";
export function fetchUniversities(query) {
    return fetch(`http://220.maxkuechen.com/universities/search?name=${query}`)
        .then(response => response.json())
        .then((json) => {
        const uniArr = [];
        json.forEach(o => uniArr.push(o.name));
        return uniArr;
    });
}
//# sourceMappingURL=fetchUniversities.js.map