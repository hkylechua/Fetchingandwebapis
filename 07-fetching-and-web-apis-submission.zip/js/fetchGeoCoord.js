import fetch from "../include/fetch.js";
export function getGeoData(query) {
    return fetch(`https://220.maxkuechen.com/geoCoord/search?q=${query}`)
        .then(response => {
        if (!response.ok) {
            throw new Error("No results found for query.");
        }
        return response.json();
    })
        .then((json) => Array.isArray(json) && json.length > 0
        ? Promise.resolve(json[0])
        : Promise.reject(new Error("No results found for query.")));
}
export function fetchGeoCoord(query) {
    return getGeoData(query).then((geo) => ({
        lat: Number.parseFloat(geo.lat),
        lon: Number.parseFloat(geo.lon),
    }));
}
//# sourceMappingURL=fetchGeoCoord.js.map